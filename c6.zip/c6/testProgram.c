int main(int x) {
	
	println(noArguments());	// 10

	println(twoArguments(4,5));	// 20
	
	return 0;
}

int noArguments() {
	return 10;
}

int twoArguments(int x, int y) {
	return x * y;
}

// Testing declaration after definition:
int noArguments();

// Testing failed declaration because of incorrect arguments:
// int noArguments(int y);

// Testing failed declaration because already defined:
// int twoArguments(int x, int y) {
//     return x + y;
// }



// FROM LIBRARY.C

int putchar(int c);

int print(int n) {
  if(n < 0){
    putchar(45);
    n = -n;
  }
  if(n < 0){
    putchar(50);
    putchar(49);
    putchar(52);
    putchar(55);
    putchar(52);
    putchar(56);
    putchar(51);
    putchar(54);
    putchar(52);
    putchar(56);
  } else {
    if(n >= 10){
      print(n/10);
    }
    putchar(n%10 + 48);
  }
  return 0;
}

int println(int n) {
  print(n);
  putchar(10);
  return 0;
}
