import java.util.HashMap;
import java.util.Map;

/**
 * A <code>Program</code> combines together zero or more procedures.
 */

public class Program {

	private Map<String, Procedure> declaredProcedures;
	private Map<String, DefinedProcedure> definedProcedures;

	/** Constructs a <code>Program</code> with the first procedure.
	 */
	public Program(Procedure procedure) {
		declaredProcedures = new HashMap<String, Procedure>();
		definedProcedures = new HashMap<String, DefinedProcedure>();
		addProcedure(procedure);
	}
	
	/**
	 * Add the procedure to the program.
	 */
	public Program addProcedure(Procedure procedure) {
		if (declaredProcedures.containsKey(procedure.getName()) && !procedure.compareArgNames(declaredProcedures.get(procedure.getName()))) {
			throw new RuntimeException("Procedure " + procedure.getName() + " has already been declared with different arguments.");
		}
		
		if (definedProcedures.containsKey(procedure.getName()) && !procedure.compareArgNames(definedProcedures.get(procedure.getName()))) {
			throw new RuntimeException("Procedure " + procedure.getName() + " has already been defined with different arguments.");
		}
		
		if (procedure instanceof DefinedProcedure) {
			if (definedProcedures.containsKey(procedure.getName())) {
				throw new RuntimeException("Procedure " + procedure.getName() + " has already been defined.");
			}
			definedProcedures.put(procedure.getName(), (DefinedProcedure)procedure);
		} else {
			declaredProcedures.put(procedure.getName(), procedure);
		}
		
		return this;
	}
	
	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	public String toLLVM() {
		String body = "";
		for(Procedure procedure : declaredProcedures.values()) {
			if(!definedProcedures.containsKey(procedure.getName())) {
				body += procedure.toLLVM();
			}
		}
		for(Procedure procedure : definedProcedures.values()) {
			body += procedure.toLLVM();
		}
		return body;
	}
}
