import java.util.ArrayList;
import java.util.List;

/**
 * An expression evaluated by calling a named procedure.
 * Limitations: the procedure must return an <code>int</code> value.
 */

public class CallExpr extends Expr {

	private String procName;
	private List<Expr> arguments;

	/** Constructs a <code>CallExpr</code> with a given procedure name and argument.
	 *  @param procName the name of the procedure to call
	 *  @param argument the expression that computes the argument value
	 */

	public CallExpr(String procName, List<Expr> arguments) {
		this.procName = procName;
		this.arguments = arguments;
	}
	
	public CallExpr(String procName) {
		this(procName, new ArrayList<Expr>());
	}
	
	public CallExpr(String procName, Expr argument) {
		this(procName);
		arguments.add(argument);
	}

	/**
	 * Generate the LLVM code that should be executed to evaluate this expression.
	 * @return the LLVM code for the expression
	 */
	public ValueAndCode toLLVM() {
		String value = NameAllocator.getTempAllocator().next();
		List<ValueAndCode> valueAndCodes = generateArgValueAndCodes();
		String code = getArgCode(valueAndCodes) +
				"    " + value + " = call i32 @" + procName + "(" + getArgValues(valueAndCodes) + ")\n";
		return new ValueAndCode(value, code);
	}
	
	/**
	 * Generate the ValueAndCode objects for the arguments of the procedure call.
	 * @return the ValueAndCode objects for the arguments of the procedure call
	 */
	protected List<ValueAndCode> generateArgValueAndCodes() {
		List<ValueAndCode> argValueAndCodes = new ArrayList<ValueAndCode>();
		for(Expr argument : arguments) {
			argValueAndCodes.add(argument.toLLVM());
		}
		return argValueAndCodes;
	}
	
	/**
	 * Get the code for the arguments from their ValueAndCode objects.
	 * @param argValueAndCodes the ValueAndCode objects
	 * @return the arguments' code
	 */
	protected String getArgCode(List<ValueAndCode> argValueAndCodes) {
		String argCode = "";
		for(ValueAndCode argValueAndCode : argValueAndCodes) {
			argCode += argValueAndCode.getCode();
		}
		return argCode;
	}
	
	/**
	 * Get the values for the arguments from their ValueAndCode objects.
	 * @param argValueAndCodes
	 * @return a String of the arguments' values, comma-separated
	 */
	protected String getArgValues(List<ValueAndCode> argValueAndCodes) {
		String argValues = "";
		for(ValueAndCode argValueAndCode : argValueAndCodes) {
			if(!argValues.isEmpty()) argValues += ", "; 
			
			argValues += "i32 " + argValueAndCode.getValue();
		}
		return argValues;
	}
}
