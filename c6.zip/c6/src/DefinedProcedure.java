import java.util.HashMap;
import java.util.List;

/**
 * A defined procedure.
 */
public class DefinedProcedure extends DeclaredProcedure {

	private Stmt body;

	/**
	 * Constructs a <code>DefinedProcedure</code> with specified name, argument names, and body.
	 * @param name the procedure's name
	 * @param body the statement to execute when the procedure is called
	 */
	public DefinedProcedure(String name, List<String> argNames, Stmt body){
		super(name, argNames);
		this.body = body;
	}
	
	/**
	 * Generate the LLVM code that defines this procedure.
	 * @return a string of LLVM code
	 */
	public String toLLVM(){
		
		String result = "";
		SymbolTable.getInstance().addScope();
		
		HashMap<String, String> values = new HashMap<String, String>();
		for (String argName : argNames) {
			values.put(argName, NameAllocator.getTempAllocator().next());
		}
		
		result = headerToLLVM("define", values);
		result += " {\n";
		result += argsToLLVM(values);
		result += body.toLLVM();
		result += "}\n";
		
		SymbolTable.getInstance().removeScope();
		
		return result;
	}
	
	/**
	 * Generate the LLVM code for the initialization of all arguments of this procedure.
	 * @param values he values in which to store the arguments
	 * @return a string of LLVM code
	 */
	protected String argsToLLVM(HashMap<String, String> values) {
		String argInits = "";
		for (String argName : argNames) {
			argInits += initializeArg(argName, values.get(argName));
		}
		return argInits;
	}
	
	/**
	 * Generate the LLVM code for the initialization of one argument of this procedure.
	 * @param argName the argument name
	 * @param value the value in which to store the argument
	 * @return a string of LLVM code
	 */
	protected String initializeArg(String argName, String value) {
		String argValue = NameAllocator.getTempAllocator().next();
		SymbolTable.getInstance().setSymbol(argName, argValue);
		
		String argInit = argValue + " = alloca i32 ; parameter " + argName + "\n";
		argInit += "store i32 " + value + ", i32* " + argValue + "\n";
		
		return argInit;
	}
}
