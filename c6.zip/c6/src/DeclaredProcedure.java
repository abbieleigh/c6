import java.util.HashMap;
import java.util.List;

/**
 * A declared procedure.
 */
public class DeclaredProcedure implements Procedure {

	protected String name;
	protected List<String> argNames;

	/**
	 * Constructs a <code>DeclaredProcedure</code> with specified name and argument names.
	 * @param name
	 * @param argNames
	 */
	public DeclaredProcedure(String name, List<String> argNames) {
		this.name = name;
		this.argNames = argNames;
	}

	/**
	 * Get the name for the procedure.
	 * @return the procedure's name
	 */
	@Override
	public String getName() {
		return name;
	}
	
	/**
	 * Get the argument names for the procedure.
	 * @return a list of the procedure's arguments
	 */
	@Override
	public List<String> getArgNames() {
		return argNames;
	}

	/**
	 * Generate the LLVM code that defines this procedure.
	 * @return a string of LLVM code
	 */
	@Override
	public String toLLVM() {
		String result = "";
		SymbolTable.getInstance().addScope();
		
		HashMap<String, String> values = new HashMap<String, String>();
		for (String argName : argNames) {
			values.put(argName, NameAllocator.getTempAllocator().next());
		}
		
		result = headerToLLVM("declare", values) + "\n";
		
		SymbolTable.getInstance().removeScope();
		
		return result;
	}

	/**
	 * Compare the argument names of the given procedure to those of this DeclaredProcedure.
	 * @param procedure the given procedure to compare against
	 * @return true if the lists of argument names are equivalent, otherwise false
	 */
	@Override
	public boolean compareArgNames(Procedure procedure) {
		List<String> names = procedure.getArgNames();
		if (names.size() != argNames.size()) return false;
		
		for (int i = 0; i < names.size(); i++) {
			if (!names.get(i).equals(argNames.get(i))) return false;
		}
		return true;
	}
	
	/**
	 * Generate the LLVM code for the header of this procedure.
	 * @param keyword declare or define
	 * @param values the values that the argument values are stored in
	 * @return a string of LLVM code
	 */
	protected String headerToLLVM(String keyword, HashMap<String, String> values) {
		String header = keyword + " i32 @" + name;
		String headerArgs = "";
		
		for (String argName : argNames) {
			if(!headerArgs.isEmpty()) headerArgs += ", ";
			headerArgs += "i32 " + values.get(argName);
		}
		
		header += "(" + headerArgs + ")";
		return header;
	}

}
