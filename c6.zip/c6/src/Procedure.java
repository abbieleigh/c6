import java.util.List;

/**
 * The interface for an Abstract Syntax Tree (AST) node representing a procedure.
 */
public interface Procedure {
	
	public String getName();
	public List<String> getArgNames();
	public String toLLVM();
	public boolean compareArgNames(Procedure procedure);
}
