/**
 * A statement that consists of a (parenthesized) conditional expression followed by
 * a statement to execute if the conditional expression evaluates to true, followed by
 * 0 or 1 statements to execute if the conditional expression evaluates to false.
 */
public class IfStmt extends BranchingStmt {

	protected Expr condition;
	protected Stmt ifBody, elseBody;
	
	/**
	 * Generate an <code>IfStmt<code> object.
	 * @param condition the conditional expression
	 * @param ifBody the statement to execute if the conditional expression evaluates to true
	 * @param elseBody the statement to execute if the conditional expression evaluates to false
	 */
	public IfStmt(Expr condition, Stmt ifBody, Stmt elseBody) {
		this.condition = condition;
		this.ifBody = ifBody;
		this.elseBody = elseBody;
	}
	
	/**
	 * Generate the LLVM code that should be executed to execute this statement.
	 */
	@Override
	public String toLLVM() {
		String ifLabel = NameAllocator.getLabelAllocator().next();
		String elseLabel = NameAllocator.getLabelAllocator().next();
		String exitLabel = NameAllocator.getLabelAllocator().next();
		
		String llvm = generateConditionLlvm(ifLabel, elseLabel, condition);
		llvm += generateBodyLlvm(ifLabel, exitLabel, ifBody);
		llvm += generateBodyLlvm(elseLabel, exitLabel, elseBody);
		llvm += generateLabelLlvm(exitLabel);
		
		return llvm;
	}
}
